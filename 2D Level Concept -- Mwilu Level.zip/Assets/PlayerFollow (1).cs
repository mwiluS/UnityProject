using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerFollow : MonoBehaviour
{
    //Everything in Unity has a Transform, so we can use it to access the target, no matter what type of Object it is!
    private Transform target;
    public Vector3 offset = Vector3.zero;   //Offset if we don't want the camera directly on the player.
                                            //A Vector3 is a representation
                                            //of x, y, and z positions. This is 2D, so Z isn't being used,
                                            //but we still to include it.
    public float smoothing = 2f;            //Smoothing amount for the camera's movement.

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;  //Look for a GameObject with the tag "Player" and grab its
                                                                        //Transform. Remember to set the tag in the Editor!
    }

    //Runs every frame, after everything else has been updated. This matters because the Player has to be in position before
    //the camera knows where to look
    void LateUpdate()
    {
        //Temporary variable. This is used to keep track of where the target is at all times.
        //Vector3(x position, y position, z position.) We want the target's x and y, but maintain the camera's
        //current z, since there is no depth in 2D
        Vector3 targetPos = new Vector3(target.position.x, target.position.y, transform.position.z);

        //Change the Camera's position to the target's position plus whatever the offset is.
        //Vector3.Lerp is "linear interpolation" and is used for smooth movement.
        //Parameters of Lerp are (starting point, ending point, speed of movement)
        //Time.deltaTime is the time between frames.
        transform.position = Vector3.Lerp(transform.position, targetPos + offset,
            smoothing * Time.deltaTime);
    }
}
