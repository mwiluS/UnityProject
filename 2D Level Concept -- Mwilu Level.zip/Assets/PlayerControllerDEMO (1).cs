using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayerControllerDEMO : MonoBehaviour
{
    //Floats are decimal numbers. If the number has decimals, you have to add the letter "f" at the end
    //e.g., float cost = 2.25f;
    public float moveSpeed = 5;

    /*Jump stuff
     * Make sure the player is on the ground first. JumpHeight is the power of the power of the jump,
     * fallMultiplier and lowJumpMultiplier are to make your character fall quicker on the descent from a jump.*/
    public bool grounded;

    public float jumpHeight = 12f;
    public float fallMultiplier = 8f;
    public float lowJumpMultiplier = 2f;

    

    //Rigidbody2D. Unity allows variables for Components!

    //Two steps for variables - declaration and initialization
    private Rigidbody2D rb2d;

    //LayerMask so we can check for collisions on a specific layer. For this, we only care if the player is standing on
    //the ground layer for jumping.
    public LayerMask groundLayer;

    //Create a bool called hasCoin.
    public bool hasCoin = false;

    public bool[] inventoryFull;
    public GameObject[] inventorySlots;

    // Start is called before the first frame update
    void Start()
    {
        //You have to initialize the component. This will look for a Component on the same object that this script is on.
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        //Two temporary float variables.
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");    
        //Horizontal and vertical axis is (by default) WASD and the arrows.
        //Change to "GetAxisRaw" if you would like immediate movement instead of a "ramp up" effect.

        //Raycast is one of the ways to check for collisions. Think about it like a "line of collisions"
        //Raycast has a lot of optional parameters, but the required ones are:
        //(Starting point of the raycast, direction [this is a built-in Vector for (0, -1)],
        //the size of the Vector, and the layer
        grounded = Physics2D.Raycast(transform.position, Vector2.down, 1.5f, groundLayer);

        //Call the MoveCharacter and HandleJump functions.
        //MoveCharacter is being sent the two temp float variables
        MoveCharacter(h, v);
        HandleJump();
    }

    //MoveCharacter is being sent two floats, so it needs to store them somewhere
    void MoveCharacter(float hMove, float vMove)
    {
        //Set the velocity of the rb2d to a Vector2
        //Whatever hSpeed is * moveSpeed, then leave y velocity alone
        rb2d.velocity = new Vector2(hMove * moveSpeed, rb2d.velocity.y);
    }

    void HandleJump()
    {
        
        

        //if the character isGrounded and hits the Spacebar
        if (grounded && Input.GetKeyDown(KeyCode.Space))
        {
            //Add a force to the rigidbody
            //This will add a force upward * jumpHeight.
            //ForceMode2D.Impulse means "add the force on the same frame as it is called"
            rb2d.AddForce(Vector2.up * jumpHeight, ForceMode2D.Impulse);
        }

        //If the rigidbody's y velocity is < 0, speed up the fall
        if (rb2d.velocity.y < 0)
        {
            
                //Add the fallMultiplier to the velocity. 
                //Calculation is Vector2.up * gravity * the fall Multiplier
                //-1 from fall multiplier so it does not speed up, and multiplied by
                //deltaTime to fix frame jitter.
                rb2d.velocity += (Vector2.up * Physics2D.gravity.y * fallMultiplier *
                    Time.deltaTime);
                //If the player is moving upward and no longer hitting space
                //This is for "taps" of the key instead of holds, and it will make
                //a short jump!
           
        }
        else if (rb2d.velocity.y > 0 && !Input.GetKeyDown(KeyCode.Space))
        {
            rb2d.velocity += (Vector2.up * Physics2D.gravity * lowJumpMultiplier *
                Time.deltaTime);
        }

    }

    //OnCollisionEnter and OnTriggerEnter are not the same thing!
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //If the thing you collided with is on a gameObject called
        //coin, change "hasCoin" to true, and then remove the object
        if (collision.gameObject.name == "Coin")
        {
            hasCoin = true;
            Destroy(collision.gameObject);
        }


    }


}
