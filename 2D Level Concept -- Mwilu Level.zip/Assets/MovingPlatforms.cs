using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatforms : MonoBehaviour
{
    public Transform pointA;
    public Transform pointB;
    public float movingSpeed = 1.5f;

    private Vector3 nextPos;

    // Start is called before the first frame update
    void Start()
    {
        nextPos = pointB.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, nextPos, movingSpeed * Time.deltaTime);
        if(transform.position == nextPos)
        {
            if(nextPos == pointA.position)
            {
                nextPos = pointB.position;
            }
            else
            {
                nextPos = pointA.position;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player")){
            collision.gameObject.transform.parent = transform;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player")){
            collision.gameObject.transform.parent = null;
        }
    }
}
